package app.allkit.toolkit;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
