import { defineConfig } from '@playwright/test';
export default defineConfig({testDir:'./tests/ui',timeout:30000,fullyParallel:false,workers:1,use:{baseURL:'http://127.0.0.1:4173',headless:true},webServer:{command:'npx vite preview --host 127.0.0.1 --port 4173',port:4173,reuseExistingServer:true},reporter:'list'});
