$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$toolRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\toolchains'))
New-Item -ItemType Directory -Force $toolRoot | Out-Null
$jdkDir = Join-Path $toolRoot 'jdk'
if (-not (Test-Path $jdkDir)) {
  Write-Output 'Downloading portable Temurin JDK 21...'
  $metadata = Invoke-RestMethod 'https://api.adoptium.net/v3/assets/latest/21/hotspot?architecture=x64&image_type=jdk&os=windows&vendor=eclipse'
  $package = $metadata[0].binary.package
  $archive = Join-Path $toolRoot 'jdk21.zip'
  Invoke-WebRequest -Uri $package.link -OutFile $archive
  if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $package.checksum) { throw 'JDK checksum mismatch' }
  Expand-Archive -LiteralPath $archive -DestinationPath $jdkDir -Force
}
$jdk = Get-ChildItem -LiteralPath $jdkDir -Directory | Select-Object -First 1
$env:JAVA_HOME = $jdk.FullName
$env:PATH = "$($jdk.FullName)\bin;$env:PATH"
$sdkRoot = Join-Path $toolRoot 'android-sdk'
$manager = Join-Path $sdkRoot 'cmdline-tools\bin\sdkmanager.bat'
if (-not (Test-Path $manager)) {
  Write-Output 'Downloading official Android command-line tools...'
  [xml]$repository = (Invoke-WebRequest 'https://dl.google.com/android/repository/repository2-1.xml').Content
  $package = $repository.SelectNodes('//*[local-name()="remotePackage"]') | Where-Object { $_.path -eq 'cmdline-tools;latest' } | Select-Object -First 1
  $archiveNode = $package.archives.archive | Where-Object { $_.'host-os' -eq 'windows' } | Select-Object -First 1
  if (-not $archiveNode.complete.url) { throw 'No official Windows SDK tools package found.' }
  $archive = Join-Path $toolRoot 'android-tools.zip'
  if (-not (Test-Path $archive)) { Invoke-WebRequest -Uri ('https://dl.google.com/android/repository/' + $archiveNode.complete.url) -OutFile $archive }
  $checksumNode = $archiveNode.SelectSingleNode('complete/checksum')
  $expected = $checksumNode.InnerText.Trim()
  $algorithm = if ($expected.Length -eq 40) { 'SHA1' } elseif ($expected.Length -eq 64) { 'SHA256' } else { throw 'Unknown official checksum format' }
  if ((Get-FileHash -LiteralPath $archive -Algorithm $algorithm).Hash.ToLowerInvariant() -ne $expected) { throw 'Android tools checksum mismatch' }
  New-Item -ItemType Directory -Force $sdkRoot | Out-Null
  & tar.exe -xf $archive -C $sdkRoot
  if ($LASTEXITCODE -ne 0) { throw 'Android SDK archive extraction failed.' }
}
$env:ANDROID_HOME = $sdkRoot
$env:GRADLE_USER_HOME = Join-Path $toolRoot 'gradle'
Write-Output 'Installing Android SDK platform 36 and build tools...'
('y\n' * 20).Replace('\n',"`n") | & $manager "--sdk_root=$sdkRoot" --licenses
if ($LASTEXITCODE -ne 0) { throw 'SDK license setup failed.' }
& $manager "--sdk_root=$sdkRoot" 'platforms/android-36' 'build-tools/35.0.0' 'platform-tools'
if ($LASTEXITCODE -ne 0) { throw 'SDK installation failed.' }
$project = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\android'))
Set-Content -LiteralPath (Join-Path $project 'local.properties') -Value ('sdk.dir=' + $sdkRoot.Replace('\','/'))
Push-Location $project
try {
  Write-Output 'Building allkit Android debug APK...'
  & .\gradlew.bat --no-daemon --console=plain assembleDebug
  if ($LASTEXITCODE -ne 0) { throw 'Android build failed.' }
} finally { Pop-Location }
