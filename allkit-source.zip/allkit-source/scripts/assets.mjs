import sharp from 'sharp';
import fs from 'node:fs/promises';
const original = 'public/icon.png';
await sharp(original).resize(512,512).toFile('public/icon-512.png');
await sharp(original).resize(192,192).toFile('public/icon-192.png');
for (const [density,size,foreground] of [['mdpi',48,108],['hdpi',72,162],['xhdpi',96,216],['xxhdpi',144,324],['xxxhdpi',192,432]]) {
  const dir=`android/app/src/main/res/mipmap-${density}`;
  await fs.mkdir(dir,{recursive:true});
  for (const name of ['ic_launcher','ic_launcher_round']) await sharp(original).resize(size,size).toFile(`${dir}/${name}.png`);
  const small=await sharp(original).resize(Math.round(foreground*.68),Math.round(foreground*.68)).toBuffer();
  await sharp({create:{width:foreground,height:foreground,channels:4,background:'#100b4b'}}).composite([{input:small,gravity:'centre'}]).png().toFile(`${dir}/ic_launcher_foreground.png`);
}
await sharp(original).resize(1024,1024).flatten({background:'#100b4b'}).toFile('ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png');
const png=await sharp(original).resize(256,256).png().toBuffer();
const header=Buffer.alloc(22);header.writeUInt16LE(1,2);header.writeUInt16LE(1,4);header.writeUInt16LE(1,10);header.writeUInt16LE(32,12);header.writeUInt32LE(png.length,14);header.writeUInt32LE(22,18);
await fs.writeFile('public/icon.ico',Buffer.concat([header,png]));
console.log('Generated Android, iPhone, Windows and preview icon assets.');
const splashIcon=await sharp(original).resize(540,540).toBuffer();
const splash=await sharp({create:{width:2732,height:2732,channels:3,background:'#11111b'}}).composite([{input:splashIcon,gravity:'centre'}]).png().toBuffer();
for(const file of ['splash-2732x2732.png','splash-2732x2732-1.png','splash-2732x2732-2.png'])await fs.writeFile('ios/App/App/Assets.xcassets/Splash.imageset/'+file,splash);
for(const dir of await fs.readdir('android/app/src/main/res')) {
 const target='android/app/src/main/res/'+dir+'/splash.png';
 try { const {width,height}=await sharp(target).metadata();const size=Math.round(Math.min(width,height)*.25);const icon=await sharp(original).resize(size,size).toBuffer();const output=await sharp({create:{width,height,channels:3,background:'#11111b'}}).composite([{input:icon,gravity:'centre'}]).png().toBuffer();await fs.writeFile(target,output); }catch(e){if(e.message?.includes('Input file is missing'))continue;throw e;}
}
console.log('Applied allkit branding to native launch screens.');
