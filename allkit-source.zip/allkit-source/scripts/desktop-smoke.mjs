import { _electron as electron, expect } from '@playwright/test';
import path from 'node:path';
const executablePath=process.argv[2];
const app=await electron.launch({...(executablePath?{executablePath:path.resolve(executablePath)}:{args:['.']}),env:{...process.env,ALLKIT_SMOKE_TEST:'1'},timeout:60000});
try{
 const page=await app.firstWindow();
 const errors=[];page.on('pageerror',error=>errors.push(error.message));
 await expect(page.locator('.tool-card')).toHaveCount(30);
 await page.getByRole('button',{name:/^Calculator Quick/}).click();
 await page.getByRole('textbox',{name:'Expression'}).fill('18*7');
 await page.getByRole('button',{name:'=',exact:true}).click();
 await expect(page.locator('.calc-answer')).toHaveText('126');
 const isolated=await app.evaluate(({BrowserWindow})=>{const p=BrowserWindow.getAllWindows()[0].webContents.getLastWebPreferences();return p.contextIsolation&&p.sandbox&&!p.nodeIntegration;});
 if(!isolated)throw Error('Renderer isolation is not configured');
 if(errors.length)throw Error(errors.join('\n'));
 console.log('Packaged Windows app loads 30 tools, calculates correctly, and uses an isolated sandboxed renderer.');
}finally{await app.close();}
