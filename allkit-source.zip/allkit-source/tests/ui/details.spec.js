import {test,expect} from '@playwright/test';
async function open(page,name){await page.getByRole('button',{name:new RegExp('^'+name+' ')}).first().click();}
async function back(page){await page.getByRole('button',{name:/Back to/}).click();}
test('money tools, password, colors, dice, wheel and pet work',async({page})=>{
 await page.goto('/');await open(page,'Tip calculator');await expect(page.locator('.result strong')).toHaveText('57.5');await back(page);
 await open(page,'Discount calculator');await expect(page.locator('.result strong')).toHaveText('80');await page.getByRole('spinbutton',{name:'Discount (%)'}).fill('120');await expect(page.getByRole('alert')).toBeVisible();await back(page);
 await open(page,'Password generator');await page.getByRole('button',{name:'Generate password'}).click();expect((await page.locator('.password-result').textContent()).length).toBe(20);await back(page);
 await open(page,'Color picker');await page.getByRole('textbox',{name:'HEX color'}).fill('#ff0000');await expect(page.locator('.result strong')).toHaveText('255, 0, 0');await back(page);
 await open(page,'Dice roller');await page.getByRole('button',{name:'Roll the dice'}).click();const sum=Number(await page.locator('.result strong').textContent());expect(sum).toBeGreaterThanOrEqual(2);expect(sum).toBeLessThanOrEqual(12);await back(page);
 await open(page,'Wheel spinner');await page.getByRole('textbox').fill('One\nTwo');await page.getByRole('button',{name:'Spin the wheel'}).click();await expect(page.locator('.result strong')).toHaveText(/^(One|Two)$/,{timeout:5000});await back(page);
 await open(page,'Virtual pet');await page.getByRole('button',{name:'Feed',exact:true}).click();await expect(page.getByText('95%')).toBeVisible();await page.getByRole('textbox',{name:'Your friend’s name'}).fill('Pixel');await back(page);await open(page,'Virtual pet');await expect(page.getByRole('heading',{name:'Pixel',exact:true})).toBeVisible();
});
test('mobile logo, rare mascot and midnight discoveries are reachable',async({page})=>{
 await page.setViewportSize({width:390,height:844});await page.addInitScript(()=>Math.random=()=>.01);
 await page.goto('/');await expect(page.getByRole('button',{name:/golden friend/})).toBeVisible();await page.getByRole('button',{name:/golden friend/}).click();await back(page);
 for(let i=0;i<10;i++)await page.getByRole('button',{name:'allkit logo',exact:true}).click();expect(await page.evaluate(()=>JSON.parse(localStorage.getItem('allkit.unlocked')))).toEqual(expect.arrayContaining(['rare','glitch']));
 await page.clock.install({time:new Date('2026-11-12T00:00:00')});await page.clock.runFor(200);expect(await page.evaluate(()=>JSON.parse(localStorage.getItem('allkit.unlocked')))).toContain('midnight');
});
test('tool cards retain keyboard focus while the clock ticks',async({page})=>{await page.goto('/');const card=page.getByRole('button',{name:/^Calculator Quick/});await card.focus();await page.waitForTimeout(600);await expect(card).toBeFocused();});
test('camera denial is visible and an alarm survives dismissing a countdown',async({page})=>{
 await page.goto('/');await page.evaluate(()=>{localStorage.setItem('allkit.alarm',JSON.stringify({at:Date.now()+3600000,label:'Later'}));localStorage.setItem('allkit.timer',JSON.stringify({at:Date.now()+500,remaining:500}));});await page.reload();await expect(page.getByRole('alertdialog')).toBeVisible();await page.getByRole('button',{name:'Got it'}).click();expect(await page.evaluate(()=>JSON.parse(localStorage.getItem('allkit.alarm')).label)).toBe('Later');
 await page.evaluate(()=>{navigator.mediaDevices.getUserMedia=()=>Promise.reject(new DOMException('denied','NotAllowedError'));});await open(page,'QR code scanner');await page.getByRole('button',{name:'Start camera'}).click();await expect(page.getByRole('alert')).toContainText('permission was denied');
});
