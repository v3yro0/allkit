import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { Capacitor } from '@capacitor/core';
import { Share } from '@capacitor/share';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { ArrowLeftRight, Delete, RefreshCw } from 'lucide-react';
import { calculate, convert, units, format, password, randomInt, ageAt, daysBetween, dateUTC, today, textStats } from './core';
import { Field, Select, Result, CopyButton, Notice, ErrorText, safeResult } from './ui';
import { TimeTool } from './TimeTools';
import { FunTool } from './FunTools';
import { DeviceTool } from './DeviceTools';
import { read, write } from './storage';

export function ToolView(props) {
  const { id } = props;
  if (['stopwatch','timer','alarm','world','timezone'].includes(id)) return <TimeTool {...props}/>;
  if (['eightball','wheel','reaction','pet','dice'].includes(id)) return <FunTool {...props}/>;
  if (['qrscan','barcode','compass','ruler'].includes(id)) return <DeviceTool {...props}/>;
  if (id === 'calculator' || id === 'scientific') return <Calculator {...props}/>;
  if (id === 'units') return <UnitConverter/>;
  if (id === 'currency') return <Currency/>;
  if (['percentage','discount','tip'].includes(id)) return <MoneyTool id={id}/>;
  if (id === 'date' || id === 'age') return <DateTool id={id}/>;
  if (id === 'qr') return <QR {...props}/>;
  if (id === 'password') return <Password {...props}/>;
  if (id === 'color' || id === 'palette') return <Colors {...props}/>;
  if (id === 'words' || id === 'case') return <TextTool {...props}/>;
  if (id === 'random') return <Random {...props}/>;
  return null;
}
function Calculator({ id, unlock, setToast }) {
  const [input,setInput] = useState(''), [answer,setAnswer] = useState(null), [error,setError] = useState(''), [degrees,setDegrees] = useState(true), [cosmic,setCosmic] = useState(false);
  const [history,setHistory] = useState([]);
  function solve() { const r = safeResult(() => calculate(input,degrees)); setError(r.error); setAnswer(r.value); if(r.value !== null) setHistory(h => [{input,value:r.value},...h].slice(0,5)); if(r.value === 42) { unlock('fortytwo'); setCosmic(true); } }
  useEffect(() => { if(cosmic) { const t = setTimeout(() => setCosmic(false),4000); return () => clearTimeout(t); } },[cosmic]);
  const enter = value => { setInput(p => p + value); setError(''); };
  return <div className="calculator-layout"><div className={'calculator ' + (cosmic ? 'cosmic' : '')}>{id === 'scientific' && <div className="calc-mode"><button className={degrees ? 'selected' : ''} onClick={() => setDegrees(true)}>DEG</button><button className={!degrees ? 'selected' : ''} onClick={() => setDegrees(false)}>RAD</button></div>}<form onSubmit={e => {e.preventDefault();solve();}}><input className="calc-input" aria-label="Expression" placeholder="0" value={input} onChange={e => setInput(e.target.value)} autoComplete="off" inputMode={id === 'scientific' ? 'text' : 'decimal'}/></form><div className="calc-answer" aria-live="polite">{answer === null ? 'Ready when you are' : format(answer)}</div><ErrorText>{error}</ErrorText>{cosmic && <div className="cosmic-answer">✦ The answer to life, the universe, and everything. ✦</div>}{id === 'scientific' && <div className="scientific-keys">{['sin(','cos(','tan(','log(','ln(','sqrt(','π','e','^','!'].map(k => <button key={k} onClick={() => enter(k)}>{k.replace('(','')}</button>)}</div>}<div className="calc-keys">{['AC','(',')','⌫','7','8','9','÷','4','5','6','×','1','2','3','−','0','.','%','+'].map(k => <button key={k} className={['÷','×','−','+'].includes(k) ? 'operator' : ''} onClick={() => k === 'AC' ? (setInput(''),setAnswer(null),setError('')) : k === '⌫' ? setInput(p => p.slice(0,-1)) : enter(k)}>{k === '⌫' ? <Delete size={20}/> : k}</button>)}</div><button className="primary equals" onClick={solve}>=</button></div><div className="calc-history"><h3>A little working space</h3><p>{id === 'scientific' ? 'Trigonometry, powers, factorials and logarithms, all in one place.' : 'Tap the keys or type an expression. Parentheses work, too.'}</p><Notice>Percent divides a value by 100. For a 20% increase, use 100 × (1 + 20%).</Notice><h3>Recent calculations</h3>{history.length ? history.map((h,i) => <button className="history-item" key={i} onClick={() => setInput(String(h.value))}><span>{h.input}</span><strong>{format(h.value)}</strong></button>) : <p className="muted">Your calculations will appear here during this visit.</p>}{answer !== null && <CopyButton value={answer} setToast={setToast}/>}</div></div>;
}
function UnitConverter() {
  const [category,setCategory] = useState('Length'), [value,setValue] = useState('1'), [from,setFrom] = useState('m'), [to,setTo] = useState('ft');
  const r = safeResult(() => value.trim() ? convert(Number(value),category,from,to) : null);
  return <div className="tool-form"><Select label="Measurement" value={category} items={Object.keys(units)} onChange={c => {setCategory(c);setFrom(Object.keys(units[c])[0]);setTo(Object.keys(units[c])[1]);}}/><Field label="Amount" type="number" value={value} onChange={e => setValue(e.target.value)}/><div className="conversion-fields"><Select label="From" value={from} onChange={setFrom} items={Object.keys(units[category])}/><button className="icon-button swap" aria-label="Swap units" onClick={() => {setFrom(to);setTo(from);}}><ArrowLeftRight size={20}/></button><Select label="To" value={to} onChange={setTo} items={Object.keys(units[category])}/></div><ErrorText>{r.error}</ErrorText><Result>{r.value === null ? '—' : `${format(r.value)} ${to}`}</Result></div>;
}
function Currency() {
  const currencies = ['EUR','USD','GBP','HUF','JPY','CHF','CAD','AUD','CNY','INR','PLN','SEK','CZK','RON'];
  const [from,setFrom] = useState('EUR'),[to,setTo] = useState('USD'),[amount,setAmount] = useState('100'),[quote,setQuote] = useState(null),[status,setStatus] = useState(''),[retry,setRetry] = useState(0);
  useEffect(() => { const ctrl = new AbortController(); let valid = true; setQuote(null); if(from === to) {setQuote({rate:1,date:today()});setStatus('Same currency; no conversion needed.');return;} const key = `rate.${from}.${to}`, cached = read(key,null); if(cached) {setQuote(cached);setStatus('Saved reference rate · checking for an update…');} else setStatus('Fetching reference rate…');
    const timeout = setTimeout(() => ctrl.abort(),12000);
    fetch(`https://api.frankfurter.dev/v2/rate/${from.toLowerCase()}/${to.toLowerCase()}`,{signal:ctrl.signal}).then(r => {if(!r.ok) throw Error();return r.json();}).then(data => {if(!Number.isFinite(data.rate) || data.rate <= 0 || !data.date) throw Error(); if(valid) {setQuote(data);write(key,data);setStatus('Latest available reference rate · Frankfurter');}}).catch(() => {if(valid) setStatus(cached ? 'Offline or service unavailable · using a saved reference rate' : 'Could not load rates. Connect to the internet and try again.');}).finally(() => clearTimeout(timeout)); return () => {valid = false;ctrl.abort();clearTimeout(timeout);};
  },[from,to,retry]);
  return <div className="tool-form"><Field label="Amount" type="number" value={amount} onChange={e => setAmount(e.target.value)}/><div className="conversion-fields"><Select label="From" items={currencies} value={from} onChange={setFrom}/><button className="icon-button swap" aria-label="Swap currencies" onClick={() => {setFrom(to);setTo(from);}}><ArrowLeftRight size={20}/></button><Select label="To" items={currencies} value={to} onChange={setTo}/></div><Result>{quote && amount.trim() ? `${format(Number(amount) * quote.rate)} ${to}` : '—'}</Result><p className="muted" role="status">{status}{quote && <><br/>Rate date: {quote.date} · 1 {from} = {format(quote.rate)} {to}</>}</p><button className="secondary" onClick={() => setRetry(n => n + 1)}><RefreshCw size={16}/>Refresh rate</button><Notice>Reference rates are informational, not transaction quotes. Banks and payment providers may apply different rates and fees.</Notice></div>;
}
function MoneyTool({id}) {
  const [value,setValue] = useState('100'),[percent,setPercent] = useState(id === 'tip' ? '15' : '20'),[people,setPeople] = useState('2');
  const a = Number(value), p = Number(percent), n = Number(people), valid = value !== '' && percent !== '' && Number.isFinite(a) && Number.isFinite(p) && a >= 0 && p >= 0 && (id !== 'discount' || p <= 100) && (id !== 'tip' || Number.isInteger(n) && n >= 1 && n <= 10000);
  const part = a * p / 100;
  return <div className="tool-form"><div className="two-fields"><Field label={id === 'tip' ? 'Bill amount' : id === 'discount' ? 'Original price' : 'Number'} type="number" min="0" value={value} onChange={e => setValue(e.target.value)}/><Field label={id === 'tip' ? 'Tip (%)' : id === 'discount' ? 'Discount (%)' : 'Percentage (%)'} type="number" min="0" max={id === 'discount' ? 100 : undefined} value={percent} onChange={e => setPercent(e.target.value)}/></div>{id === 'tip' && <Field label="Split between (people)" type="number" min="1" max="10000" step="1" value={people} onChange={e => setPeople(e.target.value)}/>}<ErrorText>{!valid && 'Enter nonnegative amounts, a valid percentage, and a whole-number party size.'}</ErrorText><Result label={id === 'tip' ? 'Each person pays' : id === 'discount' ? 'You pay' : `${percent}% of ${value}`}>{valid ? format(id === 'tip' ? (a + part)/n : id === 'discount' ? a-part : part) : '—'}</Result>{valid && id !== 'percentage' && <div className="stat-row"><span>{id === 'tip' ? 'Total tip' : 'You save'}<strong>{format(part)}</strong></span>{id === 'tip' && <span>Total bill<strong>{format(a+part)}</strong></span>}</div>}<Notice>{id === 'tip' ? 'Amounts use the same currency as your bill. Split values may need a final rounding adjustment.' : 'Enter amounts in any currency; the result uses the same currency.'}</Notice></div>;
}
function DateTool({id}) {
  const [a,setA] = useState(id === 'age' ? '2000-01-01' : today()),[b,setB] = useState(today()),[offset,setOffset] = useState('30');
  const r = safeResult(() => id === 'age' ? ageAt(a,b) : daysBetween(a,b));
  const shifted = safeResult(() => {if(!Number.isInteger(Number(offset)) || Math.abs(Number(offset)) > 365000) throw Error('Use a whole number within ±365,000 days.'); const d = new Date(dateUTC(a) + Number(offset)*86400000); return d.toISOString().slice(0,10);});
  return <div className="tool-form"><div className="two-fields"><Field label={id === 'age' ? 'Date of birth' : 'Start date'} type="date" value={a} onChange={e => setA(e.target.value)}/><Field label={id === 'age' ? 'Age on this date' : 'End date'} type="date" value={b} onChange={e => setB(e.target.value)}/></div><ErrorText>{r.error}</ErrorText><Result label={id === 'age' ? 'Age in completed years' : 'Days between dates'}>{r.value === null ? '—' : id === 'age' ? `${r.value.years} years` : `${r.value} days`}</Result>{id === 'age' && r.value && <p className="muted">That’s {format(r.value.days)} days of you.</p>}{id === 'date' && <><Notice>End date minus start date. Negative means the end comes first. Day counts exclude the start date.</Notice><Field label="Add or subtract days from start date" type="number" step="1" value={offset} onChange={e => setOffset(e.target.value)}/><ErrorText>{shifted.error}</ErrorText><Result label="New date">{shifted.value || '—'}</Result></>}</div>;
}
function QR({setToast}) {
  async function exportQR(url) {
    try {
      if (Capacitor.isNativePlatform()) {
        const file = await Filesystem.writeFile({ path: 'allkit-qr.png', data: url.split(',')[1], directory: Directory.Cache });
        await Share.share({ title: 'allkit QR code', url: file.uri, dialogTitle: 'Save or share QR code' });
      } else { const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'allkit-qr.png'; anchor.click(); }
    } catch { setToast('Export was cancelled or unavailable. Your QR code is still shown below.'); }
  }
  const [text,setText] = useState('https://example.com'),[url,setUrl] = useState(''),[error,setError] = useState('');
  useEffect(() => {let current = true; setUrl('');setError('');if(text) QRCode.toDataURL(text,{width:800,margin:3,errorCorrectionLevel:'M',color:{dark:'#10101c',light:'#ffffff'}}).then(u => {if(current)setUrl(u);}).catch(() => {if(current)setError('This is too much text for a QR code. Try a shorter message.');});return () => {current = false;};},[text]);
  return <div className="split-tool"><div><Field label="Link or text"><textarea value={text} onChange={e => setText(e.target.value)} rows="6" maxLength="2500"/></Field><p className="muted">{text.length} characters · generated on your device</p><ErrorText>{error}</ErrorText>{url && <button className="primary" onClick={() => exportQR(url)}>Save or share QR code</button>}<Notice>Save the image on Windows, or use the native share sheet on iPhone and Android.</Notice><CopyButton value={text} setToast={setToast}/></div><div className="qr-preview">{url ? <img src={url} alt="Generated QR code"/> : <span>Your QR code will appear here.</span>}</div></div>;
}
function Password({setToast}) {
  const [length,setLength] = useState(20),[options,setOptions] = useState({lower:true,upper:true,numbers:true,symbols:true}),[value,setValue] = useState(''),[error,setError] = useState('');
  const generate = () => {const r = safeResult(() => password(Number(length),options));setValue(r.value || '');setError(r.error);};
  return <div className="tool-form"><Field label={`Length · ${length} characters`} type="range" min="8" max="128" value={length} onChange={e => setLength(e.target.value)}/><div className="checks">{[['lower','Lowercase (a–z)'],['upper','Uppercase (A–Z)'],['numbers','Numbers (0–9)'],['symbols','Symbols (!@#)']].map(([key,label]) => <label key={key}><input type="checkbox" checked={options[key]} onChange={e => setOptions(o => ({...o,[key]:e.target.checked}))}/>{label}</label>)}</div><button className="primary" onClick={generate}>Generate password</button><ErrorText>{error}</ErrorText>{value && <><Result label="Generated password"><span className="password-result">{value}</span></Result><CopyButton value={value} setToast={setToast}/></>}<Notice>Generated with your device’s cryptographic random source. Passwords are not stored. Store yours in a trusted password manager.</Notice></div>;
}
const hex = rgb => '#' + rgb.map(n => Math.round(n).toString(16).padStart(2,'0')).join('');
function hslToHex(h,s,l) {s/=100;l/=100;const k=n=>(n+h/30)%12,a=s*Math.min(l,1-l),f=n=>l-a*Math.max(-1,Math.min(k(n)-3,9-k(n),1));return hex([f(0)*255,f(8)*255,f(4)*255]);}
function Colors({id,setToast}) {
  const [color,setColor] = useState('#9b87f5'),[hexInput,setHexInput] = useState('#9b87f5'),[palette,setPalette] = useState(['#26213c','#6552a8','#9b87f5','#c6bcf8','#ede8ff']),[mode,setMode] = useState('Analogous');
  const rgb = color.match(/[a-f\d]{2}/gi)?.map(x=>parseInt(x,16)) || [0,0,0];
  const generate = () => {const h = randomInt(0,359);setPalette(Array.from({length:5},(_,i)=>hslToHex(mode === 'Monochrome' ? h : mode === 'Complementary' ? (h+(i%2)*180)%360 : (h+i*26)%360,60 + (i%2)*8,28+i*13)));};
  return id === 'color' ? <div className="split-tool"><div className="color-preview" style={{background:color}}><input aria-label="Choose a color" type="color" value={color} onChange={e=>{setColor(e.target.value);setHexInput(e.target.value);}}/><span>Tap to explore a shade</span></div><div><Field label="HEX color" value={hexInput} maxLength="7" onChange={e=>{const v=e.target.value;setHexInput(v);if(/^#[0-9a-f]{6}$/i.test(v))setColor(v);}}/><ErrorText>{!/^#[0-9a-f]{6}$/i.test(hexInput) && 'Use a # followed by six hexadecimal characters.'}</ErrorText><Result label="RGB">{rgb.join(', ')}</Result><CopyButton value={color.toUpperCase()} setToast={setToast}/><Notice>Use the color swatch to open your device’s picker.</Notice></div></div> : <div><div className="tool-form"><Select label="Palette harmony" value={mode} onChange={setMode} items={['Analogous','Monochrome','Complementary']}/><button className="primary" onClick={generate}>Find a new palette</button></div><div className="palette">{palette.map((c,i)=><button key={i} style={{background:c,color:i<2?'white':'#121020'}} onClick={async()=>{try{await navigator.clipboard.writeText(c);setToast(c+' copied.');}catch{setToast('Select the palette text to copy.');}}}><span>{c.toUpperCase()}</span></button>)}</div><CopyButton value={palette.join(', ')} label="Copy palette" setToast={setToast}/></div>;
}
function TextTool({id,setToast}) {
  const [text,setText] = useState(''),[mode,setMode] = useState('Sentence case');
  const stats = textStats(text);
  const transformed = mode === 'UPPERCASE' ? text.toLocaleUpperCase() : mode === 'lowercase' ? text.toLocaleLowerCase() : mode === 'Title Case' ? text.toLocaleLowerCase().replace(/(^|[^\p{L}\p{N}])(\p{L})/gu,(_,a,b)=>a+b.toLocaleUpperCase()) : text.toLocaleLowerCase().replace(/(^\s*|[.!?]\s+)(\p{L})/gu,(_,a,b)=>a+b.toLocaleUpperCase());
  return <div><Field label="Your text"><textarea rows="8" placeholder="A blank page. A little possibility." value={text} onChange={e=>setText(e.target.value)} maxLength="100000"/></Field>{id === 'words' ? <div className="stats-grid">{[[stats.words,'Words'],[stats.chars,'Characters'],[stats.lines,'Lines'],[stats.minutes,'Minutes to read']].map(([n,label])=><Result label={label} key={label}>{format(n)}</Result>)}</div> : <><Select label="Text style" value={mode} onChange={setMode} items={['Sentence case','UPPERCASE','lowercase','Title Case']}/><Field label="Converted text"><textarea rows="6" readOnly value={transformed}/></Field><CopyButton value={transformed} setToast={setToast}/></>}<Notice>Your text stays on this device and is cleared when you leave this tool.</Notice></div>;
}
function Random({setToast}) {const [min,setMin]=useState('1'),[max,setMax]=useState('100'),[value,setValue]=useState(null),[error,setError]=useState('');return <div className="tool-form"><div className="two-fields"><Field label="Minimum (inclusive)" type="number" step="1" value={min} onChange={e=>setMin(e.target.value)}/><Field label="Maximum (inclusive)" type="number" step="1" value={max} onChange={e=>setMax(e.target.value)}/></div><button className="primary" onClick={()=>{const r=safeResult(()=>{if(min===''||max==='')throw Error('Enter both bounds.');return randomInt(Number(min),Number(max));});setValue(r.value);setError(r.error);}}>Pick a number</button><ErrorText>{error}</ErrorText><Result label="Your random number">{value ?? '—'}</Result>{value!==null&&<CopyButton value={value} setToast={setToast}/>}<Notice>Both endpoints are included. Generated with cryptographic randomness.</Notice></div>;}
