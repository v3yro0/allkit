import React from 'react';
import { Copy } from 'lucide-react';
export function Field({ label, children, ...props }) { return <label className="field"><span>{label}</span>{children || <input {...props}/>}</label>; }
export function Select({ label, value, onChange, items }) { return <Field label={label}><select value={value} onChange={e => onChange(e.target.value)}>{items.map(item => <option key={typeof item === 'string' ? item : item[0]} value={typeof item === 'string' ? item : item[0]}>{typeof item === 'string' ? item : item[1]}</option>)}</select></Field>; }
export function Result({ label = 'Result', children }) { return <div className="result"><span>{label}</span><strong>{children}</strong></div>; }
export function CopyButton({ value, setToast, label = 'Copy result' }) { return <button className="secondary" onClick={async () => { try { await navigator.clipboard.writeText(String(value)); setToast('Copied to clipboard.'); } catch { setToast('Clipboard unavailable. Select and copy the result manually.'); } }}><Copy size={16}/>{label}</button>; }
export function Notice({ children }) { return <p className="notice">{children}</p>; }
export function ErrorText({ children }) { return children ? <p className="error" role="alert">{children}</p> : null; }
export function safeResult(fn) { try { return { value: fn(), error: '' }; } catch (e) { return { value: null, error: e.message }; } }
