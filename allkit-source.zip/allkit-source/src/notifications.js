import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
export async function scheduleAlert(id, at, title) {
  if (!Capacitor.isNativePlatform()) return 'Keep allkit open and your device awake for this alert.';
  const permission = await LocalNotifications.requestPermissions();
  if (permission.display !== 'granted') throw Error('Notifications are disabled. Enable them in device Settings to schedule an alert.');
  let exact = true;
  if (Capacitor.getPlatform() === 'android') {
    exact = (await LocalNotifications.checkExactNotificationSetting()).exact_alarm === 'granted';
  }
  await LocalNotifications.schedule({ notifications: [{ id, title, body: 'Your allkit alert is ready.', schedule: { at: new Date(at), allowWhileIdle: true }, sound: 'default' }] });
  return exact ? 'Device notification scheduled. Sound follows your device settings.' : 'Notification scheduled. Android may delay it; enable exact alarms in system Settings for precise timing.';
}
export async function cancelAlert(id) { if (Capacitor.isNativePlatform()) await LocalNotifications.cancel({ notifications: [{ id }] }); }
let audioContext;
export function primeAudio() { try { audioContext ||= new (window.AudioContext || window.webkitAudioContext)(); audioContext.resume(); } catch {} }
export function chime() {
  try { primeAudio(); for (let i = 0; i < 3; i++) { const oscillator = audioContext.createOscillator(), gain = audioContext.createGain(), t = audioContext.currentTime + i * .35; oscillator.frequency.value = 740 + i * 120; gain.gain.setValueAtTime(.12, t); gain.gain.exponentialRampToValueAtTime(.001, t + .3); oscillator.connect(gain); gain.connect(audioContext.destination); oscillator.start(t); oscillator.stop(t + .3); } } catch {}
}
