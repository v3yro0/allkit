export const units = {
  Length: { m: 1, km: 1000, cm: .01, mm: .001, in: .0254, ft: .3048, yd: .9144, mi: 1609.344 },
  Mass: { kg: 1, g: .001, mg: .000001, lb: .45359237, oz: .028349523125 },
  Volume: { L: 1, mL: .001, 'US gal': 3.785411784, 'US cup': .2365882365 },
  Area: { 'm²': 1, 'km²': 1e6, 'ft²': .09290304, acre: 4046.8564224, hectare: 10000 },
  Speed: { 'm/s': 1, 'km/h': 1 / 3.6, mph: .44704, knot: .5144444444 },
  Time: { second: 1, minute: 60, hour: 3600, day: 86400, week: 604800 },
  Data: { byte: 1, KB: 1000, MB: 1e6, GB: 1e9, KiB: 1024, MiB: 1048576, GiB: 1073741824 },
  Temperature: { '°C': 1, '°F': 1, K: 1 }
};
export function convert(value, category, from, to) {
  if (!Number.isFinite(value)) throw Error('Enter a valid number.');
  if (!(from in units[category]) || !(to in units[category])) throw Error('Select valid units.');
  if (category === 'Temperature') {
    const c = from === '°C' ? value : from === '°F' ? (value - 32) * 5 / 9 : value - 273.15;
    if (c < -273.1500001) throw Error('Temperature is below absolute zero.');
    return to === '°C' ? c : to === '°F' ? c * 9 / 5 + 32 : c + 273.15;
  }
  return value * units[category][from] / units[category][to];
}
export const format = n => Number.isFinite(n) ? new Intl.NumberFormat('en', { maximumFractionDigits: 10 }).format(n) : '—';
// A closed grammar: no eval, property access, assignments or executable JavaScript.
export function calculate(input, degrees = true) {
  const s = input.replace(/×/g, '*').replace(/÷/g, '/').replace(/π/g, 'pi').replace(/−/g, '-').replace(/\s/g, '');
  if (!s || s.length > 500) throw Error('Enter an expression (up to 500 characters).');
  const tokens = s.match(/(?:\d*\.\d+|\d+\.?\d*)(?:[eE][+-]?\d+)?|[a-z]+|[()+\-*/^%!]/g) || [];
  if (tokens.join('') !== s) throw Error('Use numbers and calculator functions only.');
  let i = 0;
  const funcs = { sqrt: Math.sqrt, abs: Math.abs, ln: Math.log, log: Math.log10,
    sin: n => Math.sin(degrees ? n * Math.PI / 180 : n), cos: n => Math.cos(degrees ? n * Math.PI / 180 : n), tan: n => Math.tan(degrees ? n * Math.PI / 180 : n) };
  function primary() {
    const t = tokens[i++]; let n;
    if (t === '(') { n = expression(); if (tokens[i++] !== ')') throw Error('Close the parentheses.'); }
    else if (t in funcs) { if (tokens[i++] !== '(') throw Error('Use function(number).'); n = funcs[t](expression()); if (tokens[i++] !== ')') throw Error('Close the parentheses.'); }
    else if (t === 'pi') n = Math.PI;
    else if (t === 'e') n = Math.E;
    else if (t && /^\d|^\./.test(t)) n = Number(t);
    else throw Error('Check the expression.');
    while (tokens[i] === '%' || tokens[i] === '!') {
      if (tokens[i++] === '%') n /= 100;
      else { if (!Number.isInteger(n) || n < 0 || n > 170) throw Error('Factorial needs an integer from 0 to 170.'); let f = 1; for (let j = 2; j <= n; j++) f *= j; n = f; }
    }
    return n;
  }
  function power() { let n = primary(); if (tokens[i] === '^') { i++; n **= unary(); } return n; }
  function unary() { if (tokens[i] === '+') { i++; return unary(); } if (tokens[i] === '-') { i++; return -unary(); } return power(); }
  function product() { let n = unary(); while (tokens[i] === '*' || tokens[i] === '/') { const op = tokens[i++], b = unary(); n = op === '*' ? n * b : n / b; } return n; }
  function expression() { let n = product(); while (tokens[i] === '+' || tokens[i] === '-') { const op = tokens[i++], b = product(); n = op === '+' ? n + b : n - b; } return n; }
  const result = expression();
  if (i !== tokens.length || !Number.isFinite(result)) throw Error('This expression has no finite result.');
  return Number(result.toPrecision(14));
}
export function randomInt(min, max) {
  if (!Number.isSafeInteger(min) || !Number.isSafeInteger(max) || min > max || max - min >= 4294967296) throw Error('Use whole numbers with a range below 4,294,967,296.');
  const range = max - min + 1, limit = Math.floor(4294967296 / range) * range;
  let n; do { n = crypto.getRandomValues(new Uint32Array(1))[0]; } while (n >= limit);
  return min + n % range;
}
export function password(length, options) {
  const groups = [options.lower && 'abcdefghijklmnopqrstuvwxyz', options.upper && 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', options.numbers && '0123456789', options.symbols && '!@#$%^&*()-_=+[]{}:;?'].filter(Boolean);
  if (!groups.length) throw Error('Choose at least one character set.');
  if (!Number.isInteger(length) || length < 8 || length > 128) throw Error('Choose a length from 8 to 128.');
  const pool = groups.join(''), out = groups.map(g => g[randomInt(0, g.length - 1)]);
  while (out.length < length) out.push(pool[randomInt(0, pool.length - 1)]);
  for (let i = out.length - 1; i > 0; i--) { const j = randomInt(0, i); [out[i], out[j]] = [out[j], out[i]]; }
  return out.join('');
}
export function dateUTC(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw Error('Choose a valid date.');
  const n = Date.parse(value + 'T00:00:00Z');
  if (!Number.isFinite(n) || new Date(n).toISOString().slice(0, 10) !== value) throw Error('Choose a valid date.');
  return n;
}
export const daysBetween = (a, b) => Math.round((dateUTC(b) - dateUTC(a)) / 86400000);
export function ageAt(birth, asOf) {
  if (dateUTC(birth) > dateUTC(asOf)) throw Error('Birth date must be on or before the comparison date.');
  const a = new Date(dateUTC(birth)), b = new Date(dateUTC(asOf));
  let years = b.getUTCFullYear() - a.getUTCFullYear();
  if (b.getUTCMonth() < a.getUTCMonth() || (b.getUTCMonth() === a.getUTCMonth() && b.getUTCDate() < a.getUTCDate())) years--;
  return { years, days: daysBetween(birth, asOf) };
}
export function textStats(value) {
  const words = [...new Intl.Segmenter(undefined, { granularity: 'word' }).segment(value)].filter(x => x.isWordLike).length;
  const chars = [...new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(value)].length;
  return { words, chars, lines: value ? value.split('\n').length : 0, minutes: Math.ceil(words / 200) };
}
export function duration(ms) { const s = Math.floor(Math.max(ms, 0) / 1000); return [Math.floor(s / 3600), Math.floor(s / 60) % 60, s % 60].map(n => String(n).padStart(2, '0')).join(':'); }
export const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
