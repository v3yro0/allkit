import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './styles.css';
class Boundary extends React.Component {
  state = { error: false };
  static getDerivedStateFromError() { return { error: true }; }
  render() { return this.state.error ? <div className="fatal"><h1>Let’s try that again.</h1><p>Something interrupted allkit. Your saved favorites are still here.</p><button onClick={() => location.reload()}>Reopen allkit</button></div> : this.props.children; }
}
createRoot(document.getElementById('root')).render(<Boundary><App/></Boundary>);
