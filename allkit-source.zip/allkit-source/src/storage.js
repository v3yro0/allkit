import { useState, useEffect } from 'react';
export function read(key, fallback) { try { const value = JSON.parse(localStorage.getItem('allkit.' + key)); return value ?? fallback; } catch { return fallback; } }
export function write(key, value) { try { localStorage.setItem('allkit.' + key, JSON.stringify(value)); } catch { /* Session still works when storage is unavailable. */ } }
export function useStore(key, initial) { const [value, setValue] = useState(() => read(key, initial)); useEffect(() => write(key, value), [key, value]); return [value, setValue]; }
