const { app, BrowserWindow, session, dialog } = require('electron');
const path = require('node:path');
app.setAppUserModelId('app.allkit.toolkit');
let mainWindow;
app.whenReady().then(() => {
  const entry = path.join(__dirname, '..', 'dist', 'index.html');
  const trusted = contents => contents === mainWindow?.webContents && contents.getURL().startsWith('file://');
  session.defaultSession.setPermissionCheckHandler((contents, permission) => trusted(contents) && ['media','clipboard-sanitized-write'].includes(permission));
  session.defaultSession.setPermissionRequestHandler(async (contents, permission, callback, details) => {
    if (!trusted(contents)) return callback(false);
    if (permission === 'media' && !details.mediaTypes?.includes('audio')) {
      const result = await dialog.showMessageBox(mainWindow, {type:'question',buttons:['Allow camera','Cancel'],defaultId:1,cancelId:1,title:'allkit camera access',message:'Allow allkit to use your camera to scan a code?',detail:'Images are processed on this device and are not uploaded.'});
      callback(result.response === 0);
    } else callback(permission === 'clipboard-sanitized-write');
  });
  mainWindow = new BrowserWindow({ show: !process.env.ALLKIT_SMOKE_TEST, width: 1320, height: 920, minWidth: 390, minHeight: 600, backgroundColor: '#10101c', title: 'allkit · Windows beta', icon: path.join(__dirname,'..','dist','icon.png'), autoHideMenuBar:true, webPreferences: { nodeIntegration:false, contextIsolation:true, sandbox:true, backgroundThrottling:false } });
  mainWindow.webContents.setWindowOpenHandler(() => ({action:'deny'}));
  mainWindow.webContents.on('will-navigate', e => e.preventDefault());
  mainWindow.loadFile(entry);
});
app.on('window-all-closed', () => app.quit());

