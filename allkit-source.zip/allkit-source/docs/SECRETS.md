# The unexpected · spoilers

1. **Retro theme:** enter ↑ ↑ ↓ ↓ ← → ← → B A on a keyboard while outside a text field, or use the pocket controller in Settings. Select the unlocked theme in Appearance.
2. **Glitch mode:** tap the allkit logo ten times. The mobile header and desktop sidebar both work. The visual effect lasts 4.5 seconds and respects reduced-motion preferences.
3. **Secret terminal:** enter `sudo allkit` in the tool search. Available fictional shell commands are `help`, `about`, `date`, `whoami`, `retro`, and `clear`. It does not execute system commands.
4. **42:** evaluate any calculator expression that produces 42. A cosmic overlay appears for four seconds.
5. **Midnight mascot:** have the app open during your device’s midnight hour (00:00–00:59). A night-owl discovery and home-screen visit appear.
6. **Developer menu:** tap the version number in Settings seven times. It shows local app diagnostics and a test-toast action.
7. **Hidden mini-game:** tap the small star in the “Simply allkit” settings card. Catch as many stars as possible in 15 seconds.
8. **Rare mascot:** each fresh app launch has a 3% chance of showing a golden visitor on the home screen. Tap the visitor to discover it.
9. **Secret purple theme:** tap the moon button in the header five times. The theme becomes available in Appearance.
10. **Completionist badge:** open all 30 general and fun tools. Discovery progress is stored on the device and visible in Settings.

Secrets remain unlocked after restarting the app. Clearing the app’s local data removes this progress.
