# Beta validation

The shared application passed 7 automated logic tests and 10 browser integration tests on Windows/Chromium.

Logic coverage: expression precedence and safe parsing, undefined/error handling, temperature and unit conversions, leap-day/date arithmetic, cryptographic random bounds, password character requirements, and Unicode word counting.

Browser coverage: all 30 tool screens opened at desktop and 390 px phone widths without horizontal page overflow or uncaught page errors; QR image round-trip decoding; calculators and unit conversion; text statistics; timer firing across navigation; stopwatch persistence; settings and easter egg interactions; simulated midnight and deterministic rare-mascot appearance; mobile logo tapping; DST nonexistent-time handling; currency calculations using a dated mocked response; tip/discount results; password generation; editable hex colors; dice bounds; wheel outcomes; virtual pet persistence; camera-denial messaging; stable keyboard focus; preserving a later alarm when a timer is dismissed.

Packaging checks passed: the packaged Windows app loaded all 30 tools, calculated correctly, and had renderer isolation and sandboxing enabled. The final portable EXE was also launched through a local CDP test connection; it extracted successfully, loaded 30 tools, and calculated 12 × 12 = 144. The Android Gradle build succeeded, and apksigner verified its debug APK signature using APK Signature Scheme v2. The iOS project parsed successfully and included its privacy manifest as a build resource; it was not compiled. The live Frankfurter endpoint returned a dated EUR/USD rate successfully.

Browser tests do not establish physical-device behavior. No physical iPhone or Android device, iOS simulator, or Windows ARM machine was used. Native camera permissions, motion sensors, share sheets, background notification timing, device sleep, and store compliance still require device and release testing.

The supplied builds are a functional beta, not an App Store, Google Play, or Microsoft Store release.
